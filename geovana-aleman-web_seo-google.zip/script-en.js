// Loader (solo corre si existe #loader en la página, ej. index.html)
window.addEventListener('load', function () {
  var loader = document.getElementById('loader');
  if (loader) {
    setTimeout(function () {
      document.body.classList.remove('loading');
      loader.addEventListener('animationend', function () { loader.remove(); });
    }, 2600);
  }
});

// Menú móvil
document.addEventListener('DOMContentLoaded', function () {
  var burger = document.querySelector('.burger');
  var links = document.querySelector('nav.links');
  if (burger && links) {
    burger.addEventListener('click', function () {
      links.classList.toggle('open');
    });
    links.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { links.classList.remove('open'); });
    });
  }

  // Resaltar el link de la página actual
  var current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('nav.links a').forEach(function (a) {
    var href = a.getAttribute('href');
    if (href === current) { a.classList.add('active'); }
  });

  // Animaciones al hacer scroll (se aplican automáticamente a bloques comunes)
  var autoSelectors = '.section-head, .s-card, .p-card, .stat-box, .stat, .t-item, .t-card, .p-step, .about-photo, .about-text, .hero-frame-wrap, .contact-info, form, .calendar-block, .tool-chip, .skill-pill, .blog-card, .svc-row, .faq-item, .about-blob-wrap, .blob-wrap, .filter-bar';
  document.querySelectorAll(autoSelectors).forEach(function (el, i) {
    el.classList.add('reveal');
    el.style.transitionDelay = (Math.min(i % 6, 5) * 0.08) + 's';
  });

  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  // Animación de conteo para las cifras (25+, 6+, 8...)
  var counters = document.querySelectorAll('[data-count]');
  if (counters.length) {
    var countIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        var target = parseInt(el.getAttribute('data-count'), 10);
        var suffix = el.getAttribute('data-suffix') || '';
        var start = 0;
        var duration = 1100;
        var startTime = null;
        function step(ts) {
          if (!startTime) startTime = ts;
          var progress = Math.min((ts - startTime) / duration, 1);
          var eased = 1 - Math.pow(1 - progress, 3);
          var val = Math.round(start + (target - start) * eased);
          el.textContent = val + suffix;
          if (progress < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
        countIO.unobserve(el);
      });
    }, { threshold: 0.4 });
    counters.forEach(function (el) { countIO.observe(el); });
  }

  // Acordeón FAQ con animación suave de alto
  document.querySelectorAll('.faq-item').forEach(function (item) {
    var summary = item.querySelector('summary');
    var answer = item.querySelector('.faq-a');
    if (!summary || !answer) return;
    summary.addEventListener('click', function (e) {
      e.preventDefault();
      var isOpen = item.hasAttribute('open');
      document.querySelectorAll('.faq-item[open]').forEach(function (openItem) {
        if (openItem !== item) {
          var a = openItem.querySelector('.faq-a');
          a.style.maxHeight = a.scrollHeight + 'px';
          requestAnimationFrame(function () { a.style.maxHeight = '0px'; });
          setTimeout(function () { openItem.removeAttribute('open'); }, 280);
        }
      });
      if (isOpen) {
        answer.style.maxHeight = answer.scrollHeight + 'px';
        requestAnimationFrame(function () { answer.style.maxHeight = '0px'; });
        setTimeout(function () { item.removeAttribute('open'); }, 280);
      } else {
        item.setAttribute('open', '');
        answer.style.maxHeight = '0px';
        requestAnimationFrame(function () { answer.style.maxHeight = answer.scrollHeight + 'px'; });
        setTimeout(function () { answer.style.maxHeight = ''; }, 300);
      }
    });
  });
});

/* ---------- Detalle de servicio (overlay compartido: Home + Servicios) ---------- */
var SERVICE_DATA = {
  identidad: {
    icon: '<svg viewBox="0 0 24 24"><path d="M12 2 L14 10 L22 12 L14 14 L12 22 L10 14 L2 12 L10 10 Z" stroke-linejoin="round"/></svg>',
    title: 'Visual identity',
    desc: 'Logo, color palette, typography and a complete brand manual: the visual system that makes you recognizable at a glance.',
    ideal: 'New businesses, or brands that want to rebuild their image from scratch.'
  },
  digital: {
    icon: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4" stroke-linecap="round"/></svg>',
    title: 'Digital design',
    desc: 'Pieces for social media, web and presentations, designed for your audience and for how content is consumed today.',
    ideal: 'Brands active on social media that need constant, coherent content.'
  },
  impreso: {
    icon: '<svg viewBox="0 0 24 24"><path d="M6 9V3h12v6M6 18H4a1 1 0 01-1-1v-6a1 1 0 011-1h16a1 1 0 011 1v6a1 1 0 01-1 1h-2M6 14h12v7H6z" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    title: 'Printed material',
    desc: 'Business cards, brochures, packaging and signage: design that holds up just as well on paper as on screen.',
    ideal: 'Businesses with a physical presence — stores, offices, events.'
  },
  editorial: {
    icon: '<svg viewBox="0 0 24 24"><path d="M12 6c-2-1.5-5-2-8-1v13c3-1 6-.5 8 1 2-1.5 5-2 8-1V5c-3-1-6-.5-8 1zM12 6v13" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    title: 'Editorial design',
    desc: 'Magazines, catalogs, books and reports laid out with clear hierarchy and comfortable reading.',
    ideal: 'Companies that regularly publish catalogs, magazines or reports.'
  },
  community: {
    icon: '<svg viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    title: 'Community management',
    desc: 'Content calendar, post design and social media management so your brand shows up every day.',
    ideal: 'Brands that want to hand off their social media without losing visual coherence.'
  },
  branding: {
    icon: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M15 9l-4 2-2 4 4-2 2-4z" stroke-linejoin="round"/></svg>',
    title: 'Branding & strategy',
    desc: 'Brand diagnosis and action plan: where your brand is headed and what each step looks like.',
    ideal: 'Established brands that feel their image no longer represents them.'
  }
};

function openServiceDetail(key) {
  var data = SERVICE_DATA[key];
  var overlay = document.getElementById('svcOverlay');
  if (!data || !overlay) return;
  overlay.querySelector('.s-icon').innerHTML = data.icon;
  overlay.querySelector('.svc-panel-title').textContent = data.title;
  overlay.querySelector('.svc-panel-desc').textContent = data.desc;
  overlay.querySelector('.svc-panel-ideal').textContent = data.ideal;
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeServiceDetail() {
  var overlay = document.getElementById('svcOverlay');
  if (!overlay) return;
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-service]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      e.preventDefault();
      openServiceDetail(el.getAttribute('data-service'));
    });
  });
  var overlay = document.getElementById('svcOverlay');
  if (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeServiceDetail();
    });
    var closeBtn = overlay.querySelector('.svc-panel-close');
    if (closeBtn) closeBtn.addEventListener('click', closeServiceDetail);
  }
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeServiceDetail();
  });
});


/* ---------- Compartir artículo ---------- */
document.addEventListener('DOMContentLoaded', function () {
  var buttons = document.querySelectorAll('[data-share]');
  if (!buttons.length) return;
  var toast = document.querySelector('.share-toast');
  function showToast(text) {
    if (!toast) return;
    toast.textContent = text; toast.classList.add('show');
    setTimeout(function () { toast.classList.remove('show'); }, 4000);
  }
  buttons.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var net = btn.getAttribute('data-share');
      var link = window.location.href.split('#')[0];
      var url = encodeURIComponent(link);
      if (net === 'linkedin') {
        window.open('https://www.linkedin.com/sharing/share-offsite/?url=' + url, '_blank', 'noopener,width=640,height=600');
      } else if (net === 'facebook') {
        window.open('https://www.facebook.com/sharer/sharer.php?u=' + url, '_blank', 'noopener,width=640,height=600');
      } else if (net === 'instagram') {
        if (navigator.share) {
          navigator.share({ title: document.title, url: link }).catch(function () {});
        } else if (navigator.clipboard) {
          navigator.clipboard.writeText(link).then(function () { showToast("Link copied. Paste it into your Instagram story or post."); });
        }
      }
    });
  });
});
